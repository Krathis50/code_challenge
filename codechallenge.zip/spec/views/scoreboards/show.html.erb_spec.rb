require 'rails_helper'

RSpec.describe "scoreboards/show", type: :view do
  before(:each) do
    @scoreboard = assign(:scoreboard, Scoreboard.create!())
  end

  it "renders attributes in <p>" do
    render
  end
end

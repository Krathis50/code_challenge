require "application_system_test_case"

class ScoreboardsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit scoreboards_url
  #
  #   assert_selector "h1", text: "Scoreboard"
  # end
end

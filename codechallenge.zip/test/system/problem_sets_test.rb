require "application_system_test_case"

class ProblemSetsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit problem_sets_url
  #
  #   assert_selector "h1", text: "ProblemSet"
  # end
end

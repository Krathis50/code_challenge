class Scoreboard < ApplicationRecord
end

class ProblemSet < ApplicationRecord
  belongs_to :challenge
end

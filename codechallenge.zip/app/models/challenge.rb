class Challenge < ApplicationRecord
  has_many :problem_sets
end

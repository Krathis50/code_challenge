module GetInput
    class GetInput 
        def update(input)
            puts "I'm in GetInput"
        end
    end
end

#a="ARG0"
#print(a)

#